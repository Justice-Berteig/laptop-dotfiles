return {
  "tpope/vim-sleuth",
}
